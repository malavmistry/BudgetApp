using System;
using System.Collections.Generic;

namespace BudgetApp.Models
{
    public class Category
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string? Description { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public ICollection<BudgetItem> BudgetItems { get; set; } = new List<BudgetItem>();
    }
}
